# Projeto3-lp1
Repositório para o projeto 3 da disciplina de linguagem de programação

Compilação: Basta digitar "make" no diretório raiz do projeto.

Execução: A execução de ser do tipo: "./bin/loja" no Linux.

Obs: Para o git, é necessária a criação das pastas "build" e "lib".
