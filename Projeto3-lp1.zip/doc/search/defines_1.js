var searchData=
[
  ['qtde',['qtde',['../main_8cpp.html#ad8ffda8b8c3011a7befedc09b667af30',1,'main.cpp']]],
  ['qtde_5ftipos',['qtde_tipos',['../bancodados_8cpp.html#ad6eeee151ebe708944df43ef67d34f6b',1,'bancodados.cpp']]],
  ['qtde_5fvendas',['qtde_vendas',['../bancodados_8cpp.html#ad88e0e1947250d3ea10241abf37ae30d',1,'bancodados.cpp']]]
];
