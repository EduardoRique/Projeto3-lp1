var searchData=
[
  ['validade',['validade',['../classPerecivel.html#a3674f656a1ddd9566c33011d9316e2f8',1,'Perecivel']]]
];
