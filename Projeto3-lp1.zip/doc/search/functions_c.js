var searchData=
[
  ['recebefloat',['recebeFloat',['../funcoes_8h.html#ad50ffdcfecc6907b77dfd91f5bdb8955',1,'recebeFloat(string msg, int min):&#160;funcoes.cpp'],['../funcoes_8cpp.html#ad50ffdcfecc6907b77dfd91f5bdb8955',1,'recebeFloat(string msg, int min):&#160;funcoes.cpp']]],
  ['recebeint',['recebeInt',['../funcoes_8h.html#aa3806e8dd87cc6749d8b5538dc9d3314',1,'recebeInt(string msg, int min, int max=0):&#160;funcoes.cpp'],['../funcoes_8cpp.html#ae30162a7ccd43ce00c751b1fb0efe785',1,'recebeInt(string msg, int min, int max):&#160;funcoes.cpp']]],
  ['recebestring',['recebeString',['../funcoes_8h.html#ab7110f5deede219ac8d8500924d8fc46',1,'recebeString(string msg):&#160;funcoes.cpp'],['../funcoes_8cpp.html#ab7110f5deede219ac8d8500924d8fc46',1,'recebeString(string msg):&#160;funcoes.cpp']]],
  ['remove_5facentos',['remove_acentos',['../funcoes_8h.html#a62a3caae350a79af034210496404d4e7',1,'remove_acentos(string &amp;s):&#160;funcoes.cpp'],['../funcoes_8cpp.html#a62a3caae350a79af034210496404d4e7',1,'remove_acentos(string &amp;s):&#160;funcoes.cpp']]],
  ['removepos',['RemovePos',['../classLista.html#a1bc429b7bd3b0094cdcb67b4196daf21',1,'Lista']]],
  ['removeval',['RemoveVal',['../classLista.html#ad9c3b251429f5a65c82300ab570373fb',1,'Lista']]]
];
