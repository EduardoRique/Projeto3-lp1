var searchData=
[
  ['genero',['genero',['../classDVD.html#ad225e9beb4e67049e80db465d1910026',1,'DVD']]],
  ['glicose',['glicose',['../classDoce.html#aaec7340a045c73fec5ef50421d84383d',1,'Doce']]],
  ['gluten',['gluten',['../classDoce.html#a4cb3a5ab63d45bd5ac19fb051a4cc570',1,'Doce::gluten()'],['../classSalgado.html#a64861eb6ff1c59e0550a7da2e8243f0c',1,'Salgado::gluten()']]]
];
