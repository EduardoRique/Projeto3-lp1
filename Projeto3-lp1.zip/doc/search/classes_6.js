var searchData=
[
  ['salgado',['Salgado',['../classSalgado.html',1,'']]]
];
