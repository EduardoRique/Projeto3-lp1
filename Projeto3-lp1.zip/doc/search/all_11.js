var searchData=
[
  ['validade',['validade',['../classPerecivel.html#a3674f656a1ddd9566c33011d9316e2f8',1,'Perecivel']]],
  ['venda',['Venda',['../classVenda.html',1,'Venda'],['../classVenda.html#a80246070290a58d69d7b332134a16c53',1,'Venda::Venda()'],['../bancodados_8h.html#a2f5e6fbd88a1178100e2cdf8b2d8ddf8',1,'venda(Lista&lt; Fornecedor &gt; *e, Lista&lt; Venda &gt; *v):&#160;bancodados.cpp'],['../bancodados_8cpp.html#a2f5e6fbd88a1178100e2cdf8b2d8ddf8',1,'venda(Lista&lt; Fornecedor &gt; *e, Lista&lt; Venda &gt; *v):&#160;bancodados.cpp']]],
  ['venda_2ecpp',['venda.cpp',['../venda_8cpp.html',1,'']]],
  ['venda_2eh',['venda.h',['../venda_8h.html',1,'']]],
  ['venda_5fadd',['venda_add',['../bancodados_8h.html#ae19eb723e276ef394e23f0eaa567aac8',1,'venda_add(Lista&lt; Fornecedor &gt; *e, Lista&lt; Venda &gt; *v):&#160;bancodados.cpp'],['../bancodados_8cpp.html#ae19eb723e276ef394e23f0eaa567aac8',1,'venda_add(Lista&lt; Fornecedor &gt; *e, Lista&lt; Venda &gt; *v):&#160;bancodados.cpp']]],
  ['venda_5fdel',['venda_del',['../bancodados_8h.html#addf10d643c993e1c225577b0db9a9516',1,'venda_del(Lista&lt; Venda &gt; *v):&#160;bancodados.cpp'],['../bancodados_8cpp.html#addf10d643c993e1c225577b0db9a9516',1,'venda_del(Lista&lt; Venda &gt; *v):&#160;bancodados.cpp']]],
  ['venda_5fenc',['venda_enc',['../bancodados_8h.html#a2763c7a84114b48fa29f029ac3b789a0',1,'venda_enc(Lista&lt; Venda &gt; *v):&#160;bancodados.cpp'],['../bancodados_8cpp.html#a2763c7a84114b48fa29f029ac3b789a0',1,'venda_enc(Lista&lt; Venda &gt; *v):&#160;bancodados.cpp']]],
  ['venda_5flis',['venda_lis',['../bancodados_8h.html#a8f098b4fbdeee1dcf889cae1963d5475',1,'venda_lis(Lista&lt; Venda &gt; *v, bool pausa=true):&#160;bancodados.cpp'],['../bancodados_8cpp.html#a8adf56114462c78d259694bb18f62e74',1,'venda_lis(Lista&lt; Venda &gt; *v, bool pausa):&#160;bancodados.cpp']]]
];
