var searchData=
[
  ['opcoes',['opcoes',['../main_8cpp.html#ac6e84ac59605bee887f25105cda362eb',1,'main.cpp']]],
  ['opcoes_5fvendas',['opcoes_vendas',['../bancodados_8cpp.html#ad0a1862835ed2ee41cbd06ec0d9f0eb2',1,'bancodados.cpp']]]
];
