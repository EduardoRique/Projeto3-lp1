var searchData=
[
  ['lista',['Lista',['../classLista.html#adce924e21607848663132290be1a959d',1,'Lista::Lista()'],['../classLista.html#a1c9caebe51a82ddf43d20f15b551910d',1,'Lista::Lista(T valor)']]],
  ['livro',['Livro',['../classLivro.html#a4b89ad279d36589f7337083cdf006861',1,'Livro']]]
];
