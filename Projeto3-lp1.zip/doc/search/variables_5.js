var searchData=
[
  ['lactose',['lactose',['../classSalgado.html#a3da0d97e798773084b58f33a35384e07',1,'Salgado']]]
];
