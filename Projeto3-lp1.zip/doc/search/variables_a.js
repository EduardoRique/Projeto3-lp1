var searchData=
[
  ['sodio',['sodio',['../classSalgado.html#ac38179a3597c5b364b5c83f67516f7ff',1,'Salgado']]]
];
