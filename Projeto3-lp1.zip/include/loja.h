#ifndef LOJA_H
#define LOJA_H

#include "bancodados.h"
#include "fornecedor.h"
#include "funcoes.h"
#include "lista.h"
#include "venda.h"
#include "menu.h"
#include "perecivel.h"
#include "produto.h"
#include "subproduto.h"

#endif